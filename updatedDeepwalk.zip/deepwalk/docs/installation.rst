============
Installation
============

At the command line::

    $ easy_install deepwalk

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv deepwalk
    $ pip install deepwalk